/* I forgot to implement strings so this 
   should do for a "hello world program" */
void main(void) {
    output(1234);
}