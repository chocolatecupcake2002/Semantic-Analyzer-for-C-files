void main(void) {
    int i;
    i = 0;
    while (i < 10) {
        output(i);
        i = i + 1;
    }
}